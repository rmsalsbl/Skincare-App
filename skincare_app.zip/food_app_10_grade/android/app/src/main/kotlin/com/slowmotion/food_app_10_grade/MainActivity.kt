package com.slowmotion.food_app_10_grade

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
